<!-- markdownlint-disable no-inline-html no-bare-urls line-length header-increment commands-show-output -->

# The Prototype

This prototype is a simple test to confirm that I can create a set of parameters in which there is no single dominant strategy, but skilled players can counter everything given to them.
